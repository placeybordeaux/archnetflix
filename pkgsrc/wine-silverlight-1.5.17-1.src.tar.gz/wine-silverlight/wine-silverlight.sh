export PATH=$PATH:/opt/wine-silverlight/bin
